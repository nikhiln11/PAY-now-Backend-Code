package com.dbs.studentjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JdbcStudentJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(JdbcStudentJpaApplication.class, args);
	}

}
